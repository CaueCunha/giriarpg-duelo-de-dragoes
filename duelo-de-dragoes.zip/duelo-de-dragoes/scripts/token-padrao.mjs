// GERADO por construir.py a partir de fonte/token-padrao.json. Não edite aqui.
// Padrão de token de toda ameaça/NPC do módulo (nome ao passar o mouse, visão, PV embaixo e PM azul em cima no Bar Brawl).
export const TOKEN_PADRAO = Object.freeze({
  "displayName": 30,
  "displayBars": 40,
  "sight": {
    "enabled": true
  },
  "bar1": {
    "attribute": "attributes.pv"
  },
  "bar2": {
    "attribute": "attributes.pm"
  },
  "flags": {
    "barbrawl": {
      "resourceBars": {
        "bar1": {
          "id": "bar1",
          "order": 0,
          "attribute": "attributes.pv",
          "mincolor": "#FF0000",
          "maxcolor": "#80FF00",
          "position": "bottom-inner",
          "gmVisibility": -1,
          "ownerVisibility": 50,
          "otherVisibility": 0
        },
        "bar2": {
          "id": "bar2",
          "order": 1,
          "attribute": "attributes.pm",
          "mincolor": "#000080",
          "maxcolor": "#80B3FF",
          "position": "top-inner",
          "gmVisibility": -1,
          "ownerVisibility": 50,
          "otherVisibility": 0
        }
      }
    }
  }
});
