// Duelo de Dragões: ponto de entrada do módulo.
// - Registra o menu "Importar revistas" nas configurações do módulo.
// - Ao abrir o mundo, cria e atualiza as revistas sozinho (configuração "sincronizarAuto").
// - Liga as automações da campanha (scripts/automacoes.mjs) para o mestre ativo.
// - Expõe a API em game.modules.get("duelo-de-dragoes").api e em globalThis.ddd.
import { MODULO, souMestreAtivo } from "./constantes.mjs";
import { importarRevista, removerRevista, listarRevistas, sincronizar } from "./importador.mjs";
import { ligarAutomacoes } from "./automacoes.mjs";
import { ImportadorApp } from "./importador-app.mjs";

Hooks.once("init", () => {
  game.settings.registerMenu(MODULO, "importador", {
    name: "Revistas de Duelo de Dragões",
    label: "Importar revistas",
    hint: "Cria no mundo as ameaças, itens, tabelas, macros, diários e cenas de cada revista.",
    icon: "fas fa-dragon",
    type: ImportadorApp,
    restricted: true,
  });
  game.settings.register(MODULO, "sincronizarAuto", {
    name: "Criar e atualizar as revistas no mundo automaticamente",
    hint: "Ao abrir o mundo, o mestre cria as revistas novas e atualiza as que mudaram no módulo (fichas, itens, tabelas, macros e diários). O que você editou é mantido.",
    scope: "world", config: true, type: Boolean, default: true,
  });
  game.settings.register(MODULO, "importadas", {
    scope: "world", config: false, type: Object, default: {},
  });
  const api = { importarRevista, removerRevista, listarRevistas, sincronizar, abrir: () => new ImportadorApp().render({ force: true }) };
  game.modules.get(MODULO).api = api;
  globalThis.ddd = api;
});

Hooks.once("ready", async () => {
  ligarAutomacoes();
  if (souMestreAtivo() && game.settings.get(MODULO, "sincronizarAuto")) {
    try { await sincronizar(); } catch (e) { console.error(`${MODULO} | sincronização`, e); }
  }
  if (game.user.isGM) console.log(`${MODULO} | pronto. Use ddd.abrir() ou Configurações > Duelo de Dragões > Importar revistas.`);
});
