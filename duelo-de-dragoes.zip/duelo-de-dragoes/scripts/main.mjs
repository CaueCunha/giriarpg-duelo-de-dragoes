// Duelo de Dragões: ponto de entrada do módulo.
// - Registra o menu "Importar revistas" nas configurações do módulo.
// - Liga as automações da campanha (scripts/automacoes.mjs) para o mestre ativo.
// - Expõe a API em game.modules.get("duelo-de-dragoes").api e em globalThis.ddd.
import { MODULO } from "./constantes.mjs";
import { importarRevista, removerRevista, listarRevistas } from "./importador.mjs";
import { ligarAutomacoes } from "./automacoes.mjs";
import { ImportadorApp } from "./importador-app.mjs";

Hooks.once("init", () => {
  game.settings.registerMenu(MODULO, "importador", {
    name: "Revistas de Duelo de Dragões",
    label: "Importar revistas",
    hint: "Cria no mundo as ameaças, itens, tabelas, macros, diários e cenas de cada revista.",
    icon: "fas fa-dragon",
    type: ImportadorApp,
    restricted: true,
  });
  game.settings.register(MODULO, "importadas", {
    scope: "world", config: false, type: Object, default: {},
  });
  const api = { importarRevista, removerRevista, listarRevistas, abrir: () => new ImportadorApp().render({ force: true }) };
  game.modules.get(MODULO).api = api;
  globalThis.ddd = api;
});

Hooks.once("ready", () => {
  ligarAutomacoes();
  if (game.user.isGM) console.log(`${MODULO} | pronto. Use ddd.abrir() ou Configurações > Duelo de Dragões > Importar revistas.`);
});
