// Duelo de Dragões: ponto de entrada do módulo.
// - Registra o menu "Importar revistas" nas configurações do módulo.
// - Ao abrir o mundo, põe as pastas das revistas dentro das pastas dos patamares (mundos de antes da 0.18.0)
//   faz a substituição única da versão corrigida (substituirTudo) e cria e atualiza as revistas sozinho
//   (configuração "sincronizarAuto") e atualiza uma vez o código das macros do mundo (atualizarMacros, 0.21.0).
// - Padrão de token das ameaças (scripts/tokens.mjs): hooks no setup e correção ao abrir o mundo ("corrigirTokens").
// - Liga as automações da campanha (scripts/automacoes.mjs) para o mestre ativo.
// - Armadilhas da campanha como modelos do módulo giria-t20-armadilhas (scripts/armadilhas.mjs, 0.21.3).
// - Cartões de teste no chat (scripts/testes.mjs): macros e automações pedem o teste e o jogador rola (api.testes).
// - Expõe a API em game.modules.get("duelo-de-dragoes").api e em globalThis.ddd.
import { MODULO, souMestreAtivo } from "./constantes.mjs";
import { importarRevista, removerRevista, listarRevistas, sincronizar, organizarPastas, substituirTudo, atualizarMacros } from "./importador.mjs";
import { ligarAutomacoes } from "./automacoes.mjs";
import { ligarTestes, api as apiTestes } from "./testes.mjs";
import { ImportadorApp } from "./importador-app.mjs";
import { registrarHooksTokens, corrigirTokens } from "./tokens.mjs";
import { registrarArmadilhas } from "./armadilhas.mjs";

// No setup, antes de qualquer documento ser criado, para vencer o padrão de token do mundo e o do Bar Brawl.
Hooks.once("setup", registrarHooksTokens);
// Modelos de armadilha da campanha no módulo "Giria T20 - Armadilhas", se ele estiver ativo (scripts/armadilhas.mjs).
Hooks.once("setup", registrarArmadilhas);

Hooks.once("init", () => {
  game.settings.registerMenu(MODULO, "importador", {
    name: "Revistas de Duelo de Dragões",
    label: "Importar revistas",
    hint: "Cria no mundo as ameaças, itens, tabelas, macros, diários e cenas de cada revista.",
    icon: "fas fa-dragon",
    type: ImportadorApp,
    restricted: true,
  });
  game.settings.register(MODULO, "sincronizarAuto", {
    name: "Criar e atualizar as revistas no mundo automaticamente",
    hint: "Ao abrir o mundo, o mestre cria as revistas novas e atualiza as que mudaram no módulo (fichas, itens, tabelas, macros e diários). O que você editou é mantido.",
    scope: "world", config: true, type: Boolean, default: true,
  });
  // Conexão com Dame Lia (revistas 6 a 10): valor e histórico, mexidos pela macro "R6 · Conexão com Dame Lia".
  game.settings.register(MODULO, "conexaoLia", {
    scope: "world", config: false, type: Object, default: { valor: 0, historico: [] },
  });
  // Última substituição única já feita neste mundo (ver substituirTudo em importador.mjs).
  game.settings.register(MODULO, "substituicao", {
    scope: "world", config: false, type: String, default: "",
  });
  // Última atualização única das macros já feita neste mundo (ver atualizarMacros em importador.mjs).
  game.settings.register(MODULO, "macrosAtualizadas", {
    scope: "world", config: false, type: String, default: "",
  });
  game.settings.register(MODULO, "corrigirTokens", {
    name: "Corrigir os tokens das ameaças ao abrir o mundo",
    hint: "Ao abrir o mundo, o mestre aplica o padrão de token (nome ao passar o mouse, visão, PV embaixo e PM azul em cima) nas ameaças das revistas que já estão no mundo e nos tokens delas nas cenas. A arte não muda.",
    scope: "world", config: true, type: Boolean, default: true,
  });
  game.settings.register(MODULO, "importadas", {
    scope: "world", config: false, type: Object, default: {},
  });
  const api = { testes: apiTestes, importarRevista, removerRevista, listarRevistas, sincronizar, substituirTudo, atualizarMacros, corrigirTokens, abrir: () => new ImportadorApp().render({ force: true }) };
  game.modules.get(MODULO).api = api;
  globalThis.ddd = api;
});

Hooks.once("ready", async () => {
  ligarTestes();
  ligarAutomacoes();
  if (souMestreAtivo()) {
    try { await organizarPastas(await listarRevistas()); } catch (e) { console.error(`${MODULO} | pastas`, e); }
    try { await substituirTudo(); } catch (e) { console.error(`${MODULO} | substituição`, e); }
  }
  if (souMestreAtivo() && game.settings.get(MODULO, "sincronizarAuto")) {
    try { await sincronizar(); } catch (e) { console.error(`${MODULO} | sincronização`, e); }
  }
  // Depois da sincronização: troca o código das macros que ficaram de fora (editadas ou puxadas dos compêndios).
  if (souMestreAtivo()) {
    try { await atualizarMacros(); } catch (e) { console.error(`${MODULO} | macros`, e); }
  }
  // Depois da sincronização: as fichas reimportadas já vêm certas, e sobra só o que o mestre editou.
  if (souMestreAtivo() && game.settings.get(MODULO, "corrigirTokens")) {
    try { await corrigirTokens(); } catch (e) { console.error(`${MODULO} | tokens`, e); }
  }
  if (game.user.isGM) console.log(`${MODULO} | pronto. Use ddd.abrir() ou Configurações > Duelo de Dragões > Importar revistas.`);
});
