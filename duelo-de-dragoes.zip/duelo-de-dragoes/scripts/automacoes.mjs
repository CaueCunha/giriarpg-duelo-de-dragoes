// Automações da campanha, ligadas sempre que o módulo está ativo (só o mestre ativo executa).
// Cada ficha liga o que precisa por flags, colocadas pelo pacote da revista:
//   flags["duelo-de-dragoes"].automacoes.ferocidade = true
//       Ao perder PV, recebe +2 em ataque e dano até o fim do próximo turno (carcaju).
//   flags["duelo-de-dragoes"].automacoes.soproCompartilhado = "<grupo>"
//       Só um membro do grupo usa o sopro por vez; recarrega quando um membro cai a 0 PV (cultistas).
//       O item do sopro é o que tiver flags["duelo-de-dragoes"].sopro = true (ou nome com "Sopro").
// Novas automações de revistas futuras entram aqui como novas chaves.
import { MODULO, souMestreAtivo } from "./constantes.mjs";

const pvDe = (a) => a?.system?.attributes?.pv?.value ?? 0;
const auto = (a) => a?.getFlag(MODULO, "automacoes") ?? {};
const avisarMestre = (content) => ChatMessage.create({ whisper: ChatMessage.getWhisperRecipients("GM"), content });

// PV antes da atualização, por documento. preUpdateActor roda no cliente que fez a mudança;
// o cache serve de reserva para mudanças feitas por outro cliente.
const pvCache = new Map();
const lembrar = (a) => a && pvCache.set(a.uuid, pvDe(a));

async function aplicarFerocidade(actor) {
  for (const e of actor.effects.filter((e) => e.name === "Ferocidade")) await e.delete();
  await actor.createEmbeddedDocuments("ActiveEffect", [{
    name: "Ferocidade", img: "icons/creatures/abilities/paw-print-orange.webp", type: "base",
    duration: { value: 1, units: "rounds", expiry: "turnEnd" },
    flags: { [MODULO]: { automacao: "ferocidade" } },
    system: { changes: [
      { key: "system.modificadores.ataque.geral", type: "add", value: "2", phase: "initial" },
      { key: "system.modificadores.dano.geral", type: "add", value: "2", phase: "initial" },
    ] },
  }]);
  ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor }), content: "<b>Ferocidade!</b> +2 em ataque e dano até o fim do próximo turno." });
}

const chaveSopro = (grupo) => `sopro-${grupo}`;
const soproPronto = (grupo) => canvas.scene?.getFlag(MODULO, chaveSopro(grupo)) ?? true;
const marcarSopro = (grupo, v) => canvas.scene?.setFlag(MODULO, chaveSopro(grupo), v);

async function aoMudarPV(actor, antes, agora) {
  const a = auto(actor);
  if (a.ferocidade && agora < antes) await aplicarFerocidade(actor);
  if (a.soproCompartilhado && antes > 0 && agora <= 0) {
    await marcarSopro(a.soproCompartilhado, true);
    avisarMestre(`<b>${actor.name}</b> caiu. O sopro passa para outro membro do grupo (recarregado).`);
  }
}

function itemDaMensagem(msg) {
  const dados = msg.flags?.tormenta20?.itemData;
  const ator = ChatMessage.getSpeakerActor(msg.speaker);
  const nome = dados?.name ?? "";
  const item = ator?.items.get(dados?._id) ?? ator?.items.getName(nome);
  return { ator, item, nome };
}

export function ligarAutomacoes() {
  for (const t of canvas.tokens?.placeables ?? []) lembrar(t.actor);
  Hooks.on("canvasReady", () => { pvCache.clear(); for (const t of canvas.tokens.placeables) lembrar(t.actor); });
  Hooks.on("createToken", (tok) => lembrar(tok.actor));
  Hooks.on("preUpdateActor", (actor, changes, options) => {
    if (foundry.utils.hasProperty(changes, "system.attributes.pv.value")) options[MODULO] = { pv: pvDe(actor) };
  });
  Hooks.on("updateActor", async (actor, changes, options) => {
    if (!foundry.utils.hasProperty(changes, "system.attributes.pv.value")) return;
    const antes = options[MODULO]?.pv ?? options.tormenta20?.pv ?? pvCache.get(actor.uuid);
    const agora = pvDe(actor);
    pvCache.set(actor.uuid, agora);
    if (antes === undefined || !souMestreAtivo()) return;
    await aoMudarPV(actor, antes, agora);
  });
  Hooks.on("createChatMessage", async (msg) => {
    if (!souMestreAtivo()) return;
    const { ator, item, nome } = itemDaMensagem(msg);
    const grupo = auto(ator).soproCompartilhado;
    if (!grupo) return;
    const ehSopro = item?.getFlag(MODULO, "sopro") || nome.includes("Sopro");
    if (!ehSopro) return;
    if (!soproPronto(grupo)) return avisarMestre("<b>Atenção:</b> o sopro deste grupo ainda não recarregou. Só volta quando um membro cair a 0 PV.");
    await marcarSopro(grupo, false);
    avisarMestre(`${ator.name} usou o sopro. Os outros só sopram depois que um deles cair.`);
  });
}
