// Automações da campanha, ligadas sempre que o módulo está ativo (só o mestre ativo executa).
// Cada ficha liga o que precisa por flags, colocadas pelo pacote da revista:
//   flags["duelo-de-dragoes"].automacoes.ferocidade = true
//       Ao perder PV, recebe +2 em ataque e dano até o fim do próximo turno (carcaju).
//   flags["duelo-de-dragoes"].automacoes.soproCompartilhado = "<grupo>"
//       Só um membro do grupo usa o sopro por vez; recarrega quando um membro cai a 0 PV (cultistas).
//       O item do sopro é o que tiver flags["duelo-de-dragoes"].sopro = true (ou nome com "Sopro").
//   flags["duelo-de-dragoes"].automacoes.ataqueEmBando = true
//       Ao atacar com uma arma, compara o ataque com a Defesa do alvo marcado e avisa o mestre:
//       excedeu por 10+ = dano ×2, errou = dano ×½ (turba zumbi, revista 4).
//   flags["duelo-de-dragoes"].automacoes.verVermelho = true
//       O efeito "Ver Vermelho" (+2 em perícias) desliga quando alguém usa ataque ou habilidade com a ficha como alvo
//       e religa no fim do turno dela no combate (minotauro da Manada, revista 4).
// Novas automações de revistas futuras entram aqui como novas chaves.
import { MODULO, souMestreAtivo } from "./constantes.mjs";

const pvDe = (a) => a?.system?.attributes?.pv?.value ?? 0;
const auto = (a) => a?.getFlag(MODULO, "automacoes") ?? {};
const avisarMestre = (content) => ChatMessage.create({ whisper: ChatMessage.getWhisperRecipients("GM"), content });

// PV antes da atualização, por documento. preUpdateActor roda no cliente que fez a mudança;
// o cache serve de reserva para mudanças feitas por outro cliente.
const pvCache = new Map();
const lembrar = (a) => a && pvCache.set(a.uuid, pvDe(a));

async function aplicarFerocidade(actor) {
  for (const e of actor.effects.filter((e) => e.name === "Ferocidade")) await e.delete();
  await actor.createEmbeddedDocuments("ActiveEffect", [{
    name: "Ferocidade", img: "icons/creatures/abilities/paw-print-orange.webp", type: "base",
    duration: { value: 1, units: "rounds", expiry: "turnEnd" },
    flags: { [MODULO]: { automacao: "ferocidade" } },
    system: { changes: [
      { key: "system.modificadores.ataque.geral", type: "add", value: "2", phase: "initial" },
      { key: "system.modificadores.dano.geral", type: "add", value: "2", phase: "initial" },
    ] },
  }]);
  ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor }), content: "<b>Ferocidade!</b> +2 em ataque e dano até o fim do próximo turno." });
}

const chaveSopro = (grupo) => `sopro-${grupo}`;
const soproPronto = (grupo) => canvas.scene?.getFlag(MODULO, chaveSopro(grupo)) ?? true;
const marcarSopro = (grupo, v) => canvas.scene?.setFlag(MODULO, chaveSopro(grupo), v);

async function aoMudarPV(actor, antes, agora) {
  const a = auto(actor);
  if (a.ferocidade && agora < antes) await aplicarFerocidade(actor);
  if (a.soproCompartilhado && antes > 0 && agora <= 0) {
    await marcarSopro(a.soproCompartilhado, true);
    avisarMestre(`<b>${actor.name}</b> caiu. O sopro passa para outro membro do grupo (recarregado).`);
  }
}

function itemDaMensagem(msg) {
  const dados = msg.flags?.tormenta20?.itemData;
  const ator = ChatMessage.getSpeakerActor(msg.speaker);
  const nome = dados?.name ?? "";
  const item = ator?.items.get(dados?._id) ?? ator?.items.getName(nome);
  return { ator, item, nome };
}

const VER_VERMELHO = "Ver Vermelho";

async function ataqueEmBando(msg, ator, item) {
  if (item?.type !== "arma") return;
  const ataque = msg.rolls?.find((r) => r.dice?.[0]?.faces === 20);
  if (!ataque) return;
  const alvos = [...(msg.author?.targets ?? [])];
  if (!alvos.length) return avisarMestre(`<b>Ataque em Bando</b> (${ator.name}): marque o alvo antes de atacar para o módulo comparar com a Defesa.`);
  const linhas = alvos.map((t) => {
    const defesa = t.actor?.system?.attributes?.defesa?.value ?? 0;
    const dif = ataque.total - defesa;
    const efeito = dif >= 10 ? "excedeu por 10 ou mais: dano <b>×2</b>" : dif >= 0 ? "acertou: dano normal (×1)" : "errou: ainda causa <b>metade</b> (×½)";
    return `<li>${t.name} (Defesa ${defesa}): ${efeito}</li>`;
  });
  avisarMestre(`<b>Ataque em Bando</b> de ${ator.name} (ataque ${ataque.total})<ul>${linhas.join("")}</ul>`);
}

async function ligarVerVermelho(actor, ligado) {
  const e = actor?.effects.getName(VER_VERMELHO);
  if (e && e.disabled === ligado) await e.update({ disabled: !ligado });
}

export function ligarAutomacoes() {
  for (const t of canvas.tokens?.placeables ?? []) lembrar(t.actor);
  Hooks.on("canvasReady", () => { pvCache.clear(); for (const t of canvas.tokens.placeables) lembrar(t.actor); });
  Hooks.on("createToken", (tok) => lembrar(tok.actor));
  Hooks.on("preUpdateActor", (actor, changes, options) => {
    if (foundry.utils.hasProperty(changes, "system.attributes.pv.value")) options[MODULO] = { pv: pvDe(actor) };
  });
  Hooks.on("updateActor", async (actor, changes, options) => {
    if (!foundry.utils.hasProperty(changes, "system.attributes.pv.value")) return;
    const antes = options[MODULO]?.pv ?? options.tormenta20?.pv ?? pvCache.get(actor.uuid);
    const agora = pvDe(actor);
    pvCache.set(actor.uuid, agora);
    if (antes === undefined || !souMestreAtivo()) return;
    await aoMudarPV(actor, antes, agora);
  });
  Hooks.on("combatTurnChange", async (combat, anterior) => {
    if (!souMestreAtivo()) return;
    const ator = combat.combatants.get(anterior?.combatantId)?.actor;
    if (auto(ator).verVermelho) await ligarVerVermelho(ator, true);
  });
  Hooks.on("createChatMessage", async (msg) => {
    if (!souMestreAtivo()) return;
    const { ator, item, nome } = itemDaMensagem(msg);
    if (item) {
      for (const t of msg.author?.targets ?? []) {
        if (t.actor !== ator && auto(t.actor).verVermelho) await ligarVerVermelho(t.actor, false);
      }
    }
    if (auto(ator).ataqueEmBando) await ataqueEmBando(msg, ator, item);
    const grupo = auto(ator).soproCompartilhado;
    if (!grupo) return;
    const ehSopro = item?.getFlag(MODULO, "sopro") || nome.includes("Sopro");
    if (!ehSopro) return;
    if (!soproPronto(grupo)) return avisarMestre("<b>Atenção:</b> o sopro deste grupo ainda não recarregou. Só volta quando um membro cair a 0 PV.");
    await marcarSopro(grupo, false);
    avisarMestre(`${ator.name} usou o sopro. Os outros só sopram depois que um deles cair.`);
  });
}
