// Automações da campanha, ligadas sempre que o módulo está ativo (só o mestre ativo executa).
// Cada ficha liga o que precisa por flags, colocadas pelo pacote da revista:
//   flags["duelo-de-dragoes"].automacoes.ferocidade = true
//       Ao perder PV, recebe +2 em ataque e dano até o fim do próximo turno (carcaju).
//   flags["duelo-de-dragoes"].automacoes.soproCompartilhado = "<grupo>"
//       Só um membro do grupo usa o sopro por vez; recarrega quando um membro cai a 0 PV (cultistas).
//       O item do sopro é o que tiver flags["duelo-de-dragoes"].sopro = true (ou nome com "Sopro").
//   flags["duelo-de-dragoes"].automacoes.ataqueEmBando = true
//       Ao atacar com uma arma, compara o ataque com a Defesa do alvo marcado e avisa o mestre:
//       excedeu por 10+ = dano ×2, errou = dano ×½ (turba zumbi, revista 4).
//   flags["duelo-de-dragoes"].automacoes.verVermelho = true
//       O efeito "Ver Vermelho" (+2 em perícias) desliga quando alguém usa ataque ou habilidade com a ficha como alvo
//       e religa no fim do turno dela no combate (minotauro da Manada, revista 4).
//   flags["duelo-de-dragoes"].automacoes.lutarEmFormacao = true
//       Liga o efeito "Lutar em Formação" (+2 ataque e Defesa) enquanto o token está adjacente a outro token vivo
//       com a mesma automação e a mesma disposição; desliga quando se afastam (puristas, revista 5).
//   flags["duelo-de-dragoes"].automacoes.evacuacao = <PV>
//       No início do turno com PV igual ou menor, avisa o mestre da Evacuação de Emergência (corcel de comando, revista 5).
//   flags["duelo-de-dragoes"].automacoes.auraVenenosa = { dano: "1d12", cd: 14 }
//       No início do turno de uma criatura adjacente e de outra disposição: Fortitude; falha = perde o dano e fica fraca,
//       sucesso = metade e sem condição (kallyagrai do veneno, revista 7).
//   flags["duelo-de-dragoes"].automacoes.fimToxico = { dano: "2d12", cd: 14, raio: 9 }
//       Ao cair a 0 PV, explode: cada criatura no raio (em metros) sem imunidade a veneno faz Fortitude, como acima.
//   flags["duelo-de-dragoes"].automacoes.formaDraconica = "<nome da ficha>"
//       Ao cair a 0 PV, troca o token pelo da ficha indicada (com PV e PM cheios), no mesmo lugar (Ária → Aranzirius, revista 8).
//       Não troca se a ficha tiver um efeito ativo chamado "Sem forma dracônica" (duelo amistoso da cena 3A).
//   flags["duelo-de-dragoes"].automacoes.avisoPV = { limite: <PV>, texto: "<aviso>" }
//       Avisa o mestre quando os PV caem para o limite ou menos (Tabalinn interrompe a luta com Aranzirius, revista 8).
//   flags["duelo-de-dragoes"].automacoes.auraArdente = { dano: "2d6", tipo: "fogo", pericia: "refl", cd: 17 }
//       No início do turno de qualquer outra criatura adjacente: teste da perícia; sofre o dano do tipo (metade se passar).
//       Imunidades e reduções da ficha valem (kallyagrai do fogo, revista 10).
//   flags["duelo-de-dragoes"].automacoes.curaAcelerada = <PV>
//       No início do próprio turno, cura esses PV (se estiver vivo e ferido) (duplo cultista, revista 10).
// Novas automações de revistas futuras entram aqui como novas chaves.
import { MODULO, souMestreAtivo } from "./constantes.mjs";

const pvDe = (a) => a?.system?.attributes?.pv?.value ?? 0;
const auto = (a) => a?.getFlag(MODULO, "automacoes") ?? {};
const avisarMestre = (content) => ChatMessage.create({ whisper: ChatMessage.getWhisperRecipients("GM"), content });

// PV antes da atualização, por documento. preUpdateActor roda no cliente que fez a mudança;
// o cache serve de reserva para mudanças feitas por outro cliente.
const pvCache = new Map();
const lembrar = (a) => a && pvCache.set(a.uuid, pvDe(a));

async function aplicarFerocidade(actor) {
  for (const e of actor.effects.filter((e) => e.name === "Ferocidade")) await e.delete();
  await actor.createEmbeddedDocuments("ActiveEffect", [{
    name: "Ferocidade", img: "icons/creatures/abilities/paw-print-orange.webp", type: "base",
    duration: { value: 1, units: "rounds", expiry: "turnEnd" },
    flags: { [MODULO]: { automacao: "ferocidade" } },
    system: { changes: [
      { key: "system.modificadores.ataque.geral", type: "add", value: "2", phase: "initial" },
      { key: "system.modificadores.dano.geral", type: "add", value: "2", phase: "initial" },
    ] },
  }]);
  ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor }), content: "<b>Ferocidade!</b> +2 em ataque e dano até o fim do próximo turno." });
}

const chaveSopro = (grupo) => `sopro-${grupo}`;
const soproPronto = (grupo) => canvas.scene?.getFlag(MODULO, chaveSopro(grupo)) ?? true;
const marcarSopro = (grupo, v) => canvas.scene?.setFlag(MODULO, chaveSopro(grupo), v);

async function aoMudarPV(actor, antes, agora) {
  const a = auto(actor);
  if (a.ferocidade && agora < antes) await aplicarFerocidade(actor);
  if (a.fimToxico && antes > 0 && agora <= 0) await fimToxico(actor);
  if (a.formaDraconica && antes > 0 && agora <= 0) {
    if (actor.effects.some((e) => e.name === "Sem forma dracônica" && !e.disabled)) avisarMestre(`<b>${actor.name}</b> chega a 0 PV e admite a derrota (sem forma dracônica).`);
    else await formaDraconica(actor);
  }
  if (a.avisoPV && antes > a.avisoPV.limite && agora <= a.avisoPV.limite) avisarMestre(`<b>${actor.name}</b> com ${agora} PV: ${a.avisoPV.texto}`);
  if (a.soproCompartilhado && antes > 0 && agora <= 0) {
    await marcarSopro(a.soproCompartilhado, true);
    avisarMestre(`<b>${actor.name}</b> caiu. O sopro passa para outro membro do grupo (recarregado).`);
  }
}

function itemDaMensagem(msg) {
  const dados = msg.flags?.tormenta20?.itemData;
  const ator = ChatMessage.getSpeakerActor(msg.speaker);
  const nome = dados?.name ?? "";
  const item = ator?.items.get(dados?._id) ?? ator?.items.getName(nome);
  return { ator, item, nome };
}

const VER_VERMELHO = "Ver Vermelho";

async function ataqueEmBando(msg, ator, item) {
  if (item?.type !== "arma") return;
  const ataque = msg.rolls?.find((r) => r.dice?.[0]?.faces === 20);
  if (!ataque) return;
  const alvos = [...(msg.author?.targets ?? [])];
  if (!alvos.length) return avisarMestre(`<b>Ataque em Bando</b> (${ator.name}): marque o alvo antes de atacar para o módulo comparar com a Defesa.`);
  const linhas = alvos.map((t) => {
    const defesa = t.actor?.system?.attributes?.defesa?.value ?? 0;
    const dif = ataque.total - defesa;
    const efeito = dif >= 10 ? "excedeu por 10 ou mais: dano <b>×2</b>" : dif >= 0 ? "acertou: dano normal (×1)" : "errou: ainda causa <b>metade</b> (×½)";
    return `<li>${t.name} (Defesa ${defesa}): ${efeito}</li>`;
  });
  avisarMestre(`<b>Ataque em Bando</b> de ${ator.name} (ataque ${ataque.total})<ul>${linhas.join("")}</ul>`);
}

async function ligarVerVermelho(actor, ligado) {
  const e = actor?.effects.getName(VER_VERMELHO);
  if (e && e.disabled === ligado) await e.update({ disabled: !ligado });
}

const FORMACAO = "Lutar em Formação";

// Dois tokens são adjacentes quando a folga entre os retângulos é menor que uma casa nos dois eixos.
function adjacentes(a, b) {
  const g = canvas.grid.size;
  const r = (t) => ({ x: t.document.x, y: t.document.y, w: t.document.width * g, h: t.document.height * g });
  const p = r(a), q = r(b);
  const folgaX = Math.max(q.x - (p.x + p.w), p.x - (q.x + q.w), 0);
  const folgaY = Math.max(q.y - (p.y + p.h), p.y - (q.y + q.h), 0);
  return folgaX < g && folgaY < g;
}

const imuneVeneno = (a) => /imunidade[^.;]*veneno/i.test(a?.system?.detalhes?.resistencias ?? "") || !!auto(a).auraVenenosa;
const metros = (a, b) => Math.hypot(a.center.x - b.center.x, a.center.y - b.center.y) / canvas.grid.size * (canvas.grid.distance ?? 1.5);

// Fortitude contra veneno: falha = perde o dano e fica fraco; sucesso = metade, sem condição.
async function venenoFort(alvo, dano, cd) {
  const a = alvo.actor;
  if (!a || imuneVeneno(a) || pvDe(a) <= 0) return null;
  const fort = await new Roll(`1d20 + ${a.system.pericias?.fort?.value ?? 0}`).evaluate();
  const perda = await new Roll(`${dano}[perda]`).evaluate();
  const passou = fort.total >= cd;
  await a.applyDamageV2(perda, passou ? 0.5 : 1);
  if (!passou) await a.toggleStatusEffect?.("fraco", { active: true });
  return `${alvo.name}: Fortitude ${fort.total} (CD ${cd}), ${passou ? `perde ${Math.floor(perda.total / 2)} PV` : `perde ${perda.total} PV e fica <b>fraco</b>`}`;
}

async function auraVenenosa(alvo) {
  if (!alvo?.actor || pvDe(alvo.actor) <= 0) return;
  const fontes = canvas.tokens.placeables.filter((t) => auto(t.actor).auraVenenosa && t !== alvo && pvDe(t.actor) > 0
    && t.document.disposition !== alvo.document.disposition && adjacentes(t, alvo));
  for (const f of fontes) {
    const { dano = "1d12", cd = 14 } = auto(f.actor).auraVenenosa;
    const linha = await venenoFort(alvo, dano, cd);
    if (linha) avisarMestre(`<b>Aura Venenosa</b> de ${f.name}: ${linha}.`);
  }
}

async function auraArdente(alvo) {
  if (!alvo?.actor || pvDe(alvo.actor) <= 0) return;
  const fontes = canvas.tokens.placeables.filter((t) => auto(t.actor).auraArdente && t !== alvo && pvDe(t.actor) > 0 && adjacentes(t, alvo));
  for (const f of fontes) {
    const { dano = "2d6", tipo = "fogo", pericia = "refl", cd = 17 } = auto(f.actor).auraArdente;
    const a = alvo.actor;
    const teste = await new Roll(`1d20 + ${a.system.pericias?.[pericia]?.value ?? 0}`).evaluate();
    const r = await new Roll(`${dano}[${tipo}]`).evaluate();
    const passou = teste.total >= cd;
    await a.applyDamageV2(r, passou ? 0.5 : 1);
    avisarMestre(`<b>Aura Ardente</b> de ${f.name}: ${alvo.name}, teste ${teste.total} (CD ${cd}), ${passou ? Math.floor(r.total / 2) : r.total} de ${tipo} antes de reduções.`);
  }
}

async function curaAcelerada(actor) {
  const n = Number(auto(actor).curaAcelerada) || 0;
  const pv = actor?.system?.attributes?.pv;
  if (!n || !pv || pv.value <= 0 || pv.value >= pv.max) return;
  const antes = pv.value, novo = Math.min(pv.max, antes + n);
  await actor.update({ "system.attributes.pv.value": novo });
  avisarMestre(`<b>${actor.name}</b>: cura acelerada, +${novo - antes} PV.`);
}

async function fimToxico(actor) {
  const { dano = "2d12", cd = 14, raio = 9 } = auto(actor).fimToxico;
  const origem = canvas.tokens.placeables.find((t) => t.actor === actor) ?? actor.getActiveTokens?.()[0];
  if (!origem) return;
  const linhas = [];
  for (const t of canvas.tokens.placeables) {
    if (t === origem || metros(origem, t) > raio) continue;
    const l = await venenoFort(t, dano, cd);
    if (l) linhas.push(`<li>${l}</li>`);
  }
  avisarMestre(`<b>Fim Tóxico!</b> ${actor.name} explode (raio ${raio} m).<ul>${linhas.join("") || "<li>ninguém no raio</li>"}</ul>`);
}

async function formaDraconica(actor) {
  const nome = auto(actor).formaDraconica;
  const nova = game.actors.getName(nome);
  const td = actor.token ?? actor.getActiveTokens?.()[0]?.document;
  if (!nova || !td?.parent) return avisarMestre(`<b>${actor.name}</b> chega a 0 PV e assume a forma de <b>${nome}</b>. Ponha o token dela na cena (ficha não encontrada).`);
  const dados = (await nova.getTokenDocument({ x: td.x, y: td.y, elevation: td.elevation, disposition: td.disposition, hidden: td.hidden })).toObject();
  const cena = td.parent;
  await cena.createEmbeddedDocuments("Token", [dados]);
  await cena.deleteEmbeddedDocuments("Token", [td.id]);
  avisarMestre(`<b>${actor.name}</b> chega a 0 PV e assume a forma verdadeira: <b>${nome}</b>, com PV e PM restaurados. Ponha o novo token no combate.`);
}

let formacaoPendente = null;
function atualizarFormacao() {
  if (!souMestreAtivo() || !canvas.ready) return;
  clearTimeout(formacaoPendente);
  formacaoPendente = setTimeout(async () => {
    const tropa = canvas.tokens.placeables.filter((t) => auto(t.actor).lutarEmFormacao);
    for (const t of tropa) {
      const vivo = (x) => pvDe(x.actor) > 0;
      const junto = vivo(t) && tropa.some((o) => o !== t && vivo(o) && o.document.disposition === t.document.disposition && adjacentes(t, o));
      const e = t.actor.effects.getName(FORMACAO);
      if (e && e.disabled === junto) await e.update({ disabled: !junto });
    }
  }, 150);
}

export function ligarAutomacoes() {
  for (const t of canvas.tokens?.placeables ?? []) lembrar(t.actor);
  Hooks.on("canvasReady", () => { pvCache.clear(); for (const t of canvas.tokens.placeables) lembrar(t.actor); atualizarFormacao(); });
  Hooks.on("createToken", (tok) => { lembrar(tok.actor); atualizarFormacao(); });
  Hooks.on("deleteToken", () => atualizarFormacao());
  Hooks.on("updateToken", (tok, mudou) => { if ("x" in mudou || "y" in mudou || "disposition" in mudou) atualizarFormacao(); });
  Hooks.on("preUpdateActor", (actor, changes, options) => {
    if (foundry.utils.hasProperty(changes, "system.attributes.pv.value")) options[MODULO] = { pv: pvDe(actor) };
  });
  Hooks.on("updateActor", async (actor, changes, options) => {
    if (!foundry.utils.hasProperty(changes, "system.attributes.pv.value")) return;
    const antes = options[MODULO]?.pv ?? options.tormenta20?.pv ?? pvCache.get(actor.uuid);
    const agora = pvDe(actor);
    pvCache.set(actor.uuid, agora);
    if (antes === undefined || !souMestreAtivo()) return;
    await aoMudarPV(actor, antes, agora);
    if (auto(actor).lutarEmFormacao && (antes > 0) !== (agora > 0)) atualizarFormacao();
  });
  Hooks.on("combatTurnChange", async (combat, anterior, atual) => {
    if (!souMestreAtivo()) return;
    const ator = combat.combatants.get(anterior?.combatantId)?.actor;
    if (auto(ator).verVermelho) await ligarVerVermelho(ator, true);
    const cDaVez = combat.combatants.get(atual?.combatantId);
    const daVez = cDaVez?.actor;
    if (canvas.ready && cDaVez?.token) await auraVenenosa(cDaVez.token.object);
    if (canvas.ready && cDaVez?.token) await auraArdente(cDaVez.token.object);
    if (auto(daVez).curaAcelerada) await curaAcelerada(daVez);
    const limite = auto(daVez).evacuacao;
    if (limite && pvDe(daVez) > 0 && pvDe(daVez) <= limite) {
      avisarMestre(`<b>${daVez.name}</b> começa o turno com ${pvDe(daVez)} PV: <b>Evacuação de Emergência</b>. O piloto é teleportado; `
        + "o corcel apita, fica imóvel 2 turnos e explode no fim do segundo (use o poder na ficha: 4d6 fogo + 4d6 perfuração, Ref CD 19).");
    }
  });
  Hooks.on("createChatMessage", async (msg) => {
    if (!souMestreAtivo()) return;
    const { ator, item, nome } = itemDaMensagem(msg);
    if (item) {
      for (const t of msg.author?.targets ?? []) {
        if (t.actor !== ator && auto(t.actor).verVermelho) await ligarVerVermelho(t.actor, false);
      }
    }
    if (auto(ator).ataqueEmBando) await ataqueEmBando(msg, ator, item);
    const grupo = auto(ator).soproCompartilhado;
    if (!grupo) return;
    const ehSopro = item?.getFlag(MODULO, "sopro") || nome.includes("Sopro");
    if (!ehSopro) return;
    if (!soproPronto(grupo)) return avisarMestre("<b>Atenção:</b> o sopro deste grupo ainda não recarregou. Só volta quando um membro cair a 0 PV.");
    await marcarSopro(grupo, false);
    avisarMestre(`${ator.name} usou o sopro. Os outros só sopram depois que um deles cair.`);
  });
}
