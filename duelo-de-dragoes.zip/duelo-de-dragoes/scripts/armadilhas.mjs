// Modelos de armadilha da campanha para o módulo "Giria T20 - Armadilhas" (giria-t20-armadilhas), desde 0.21.3.
// Quando os dois módulos estão ativos, estes modelos aparecem na lista do comportamento de região "Armadilha (Tormenta20)",
// ao lado das armadilhas do Livro Básico (que já incluem o Símbolo da Morte das revistas 9 e 13).
// Sem o módulo de armadilhas, nada acontece.
export const ARMADILHAS = {
  "ddd-fosso-uivantes": {
    nome: "Fosso nas Uivantes", nd: "1/4", fonte: "Duelo de Dragões #2 (tabela Encontros nas Uivantes)",
    pericia: "refl", cd: 15, sucesso: "evita", dano: "1d6[impacto]",
    texto: "A neve esconde um fosso.", falhaTexto: "cai no fosso",
  },
  "ddd-bugulentos": {
    nome: "Bugulentos!", nd: "1/2", fonte: "Duelo de Dragões #3 (covil de Cerise)",
    pericia: "refl", cd: 20, sucesso: "evita", dano: "1d12[perda]",
    texto: "Um fio derruba um barril de insetos venenosos do teto.",
    falhaTexto: "coberto de bugulentos: perde 1d12 PV no início de cada turno até se livrar (ação completa e Destreza CD 10) ou ficar em chamas",
    efeito: {
      name: "Bugulentos", img: "icons/svg/hazard.svg", type: "base", transfer: false, disabled: false,
      duration: { value: null, units: "seconds", expiry: null }, statuses: [], description: "",
      system: {
        changes: [{ key: "danoContinuo", value: "1d12[perda]", type: "custom", priority: null, phase: "initial" }],
        targets: [], status: null, onuse: false,
        abilityUse: { description: "", automatic: false, aumenta: false, custo: 0, names: [], types: [] },
        aura: { isAura: false, range: 0 },
      },
    },
    encontrar: 20, desarmar: 20,
  },
  "ddd-fogo-fatuo": {
    nome: "Fogo-fátuo", nd: "6", magica: true, area: true, fonte: "Duelo de Dragões #12",
    pericia: "vont", cd: 25, sucesso: "metade", dano: "7d6[psiquico]", condicao: "atordoado",
    texto: "Luzes dançam sobre a lama e as runas tomam a mente (dano psíquico não letal). Repete a cada rodada: clique em Disparar de novo. Cada sucesso dá uma rodada de lucidez para agir.",
    falhaTexto: "atordoado", encontrar: 30, desarmar: 30,
  },
  "ddd-sussurro-de-sszzaas": {
    nome: "Sussurro de Sszzaas", nd: "13", magica: true, area: true, fonte: "Duelo de Dragões #13",
    pericia: "vont", cd: 30, sucesso: "evita",
    texto: "Criaturas em alcance curto ouvem o sussurro do Grande Corruptor. Repete no fim de cada turno e não se desativa ao disparar (Ladinagem ou Dissipar Magia).",
    falhaTexto: "vê todos como inimigos e gasta suas ações contra os aliados", encontrar: 30, desarmar: 30,
  },
  "ddd-maldicao-do-dragao-rei": {
    nome: "Maldição do Dragão-Rei", nd: "16", magica: true, area: true, fonte: "Duelo de Dragões #19 (Covil Obscuro)",
    pericia: "fort", cd: 45, sucesso: "metade", dano: "10d12[trevas]", condicao: "alquebrado",
    texto: "As runas sob o musgo despertam em todas as criaturas em alcance curto.",
    falhaTexto: "alquebrado", encontrar: 40, desarmar: 40,
  },
};

export function registrarArmadilhas() {
  game.modules.get("giria-t20-armadilhas")?.api?.registrarModelos?.(ARMADILHAS);
}
