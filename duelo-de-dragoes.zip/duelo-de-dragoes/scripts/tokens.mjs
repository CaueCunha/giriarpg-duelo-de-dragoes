// Padrão de token das ameaças/NPCs do módulo (pedido do Cauê, 2026-11-13), igual ao Coração de Rubi:
// - preCreateActor: ameaça do módulo (flag "revista", tipo npc) entra no mundo já com o prototypeToken = TOKEN_PADRAO,
//   vencendo o padrão de token do mundo.
// - preCreateToken: token de ameaça do módulo colocado na cena sai com as barras certas, vencendo o padrão do Bar Brawl
//   (que, sem resourceBars explícitas, copia as cores da barra 1 para a barra 2).
// - corrigirTokens: ao abrir o mundo (mestre ativo, configuração "corrigirTokens"), acerta as ameaças do módulo que já
//   estão no mundo e os tokens delas nas cenas. Só mexe no que está diferente do padrão, e nunca na arte.
import { MODULO } from "./constantes.mjs";
import { TOKEN_PADRAO } from "./token-padrao.mjs";

const clone = (o) => foundry.utils.deepClone(o);
const daRevista = (doc) => doc?.type === "npc" && !!(doc.flags?.[MODULO]?.revista ?? doc.getFlag?.(MODULO, "revista"));

// Campos do token que o padrão define, em caminhos "a.b.c". Só esses são comparados e gravados: o que o Bar Brawl
// acrescenta numa barra (ou uma barra 3 que o mestre criou) fica como está, e uma ficha já certa não é tocada de novo.
function caminhos(o = TOKEN_PADRAO, p = "") {
  const r = {};
  for (const [k, v] of Object.entries(o)) {
    if (v && typeof v === "object" && !Array.isArray(v)) Object.assign(r, caminhos(v, `${p}${k}.`));
    else r[`${p}${k}`] = v;
  }
  return r;
}
const PADRAO_PLANO = caminhos();
const igual = (a, b) => JSON.stringify(a) === JSON.stringify(b);

/** O que falta para o token (dados do prototypeToken ou do token na cena) ficar no padrão; null se já está. */
export function diferencaDoPadrao(token) {
  const dif = {};
  for (const [k, v] of Object.entries(PADRAO_PLANO)) {
    if (!igual(foundry.utils.getProperty(token ?? {}, k), v)) dif[k] = clone(v);
  }
  return Object.keys(dif).length ? dif : null;
}

export function registrarHooksTokens() {
  Hooks.on("preCreateActor", (actor, dados) => {
    if (!daRevista(actor) && !daRevista(dados)) return;
    actor.updateSource({ prototypeToken: clone(TOKEN_PADRAO) });
  });
  Hooks.on("preCreateToken", (token) => {
    if (!daRevista(token.actor)) return;
    token.updateSource(clone(TOKEN_PADRAO));
  });
}

/** Acerta as ameaças do módulo no mundo e os tokens delas nas cenas. Devolve { fichas, tokens } corrigidos. */
export async function corrigirTokens({ avisar = false } = {}) {
  if (!game.user.isGM) return { fichas: 0, tokens: 0 };
  const atores = game.actors.filter((a) => daRevista(a));
  let fichas = 0, tokens = 0;
  for (const a of atores) {
    const dif = diferencaDoPadrao(a.prototypeToken?.toObject?.() ?? a.prototypeToken);
    if (!dif) continue;
    await a.update(Object.fromEntries(Object.entries(dif).map(([k, v]) => [`prototypeToken.${k}`, v])));
    fichas++;
  }
  const ids = new Set(atores.map((a) => a.id));
  for (const cena of game.scenes) {
    const lista = [];
    for (const t of cena.tokens.filter((t) => ids.has(t.actorId))) {
      const dif = diferencaDoPadrao(t.toObject?.() ?? t);
      if (dif) lista.push({ _id: t.id, ...dif });
    }
    if (!lista.length) continue;
    await cena.updateEmbeddedDocuments("Token", lista);
    tokens += lista.length;
  }
  if (avisar || fichas || tokens) {
    ui.notifications.info(`Duelo de Dragões: padrão de token aplicado em ${fichas} ficha(s) e ${tokens} token(s) nas cenas.`);
  }
  return { fichas, tokens };
}
