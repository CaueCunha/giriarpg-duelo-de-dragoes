// Pastas dos compêndios do módulo (0.21.4, pedido do Cauê).
// O module.json declara "packFolders" (Giria T20 - Duelo de Dragões (Campanha) › patamar › revista), mas o Foundry
// só monta essas pastas em alguns casos: num mundo novo os compêndios podiam aparecer soltos na aba Compendiums, e os
// compêndios de revistas novas, que chegam numa atualização do módulo, também ficavam soltos.
// Ao abrir o mundo, o mestre ativo põe cada compêndio do módulo que está sem pasta na pasta certa, criando as pastas
// que faltam (ou reaproveitando as que já existem com o mesmo nome no mesmo lugar).
// Cada compêndio é arrumado uma vez só por mundo (configuração "compendiosOrganizados"): se o mestre tirar um
// compêndio da pasta, ou apagar a pasta, o módulo não mexe de novo.
import { MODULO } from "./constantes.mjs";

const lista = (v) => Array.from(v ?? []);

async function arvoreDoManifesto() {
  const arvore = lista(game.modules.get(MODULO)?.packFolders);
  if (arvore.length) return arvore;
  try { return (await (await fetch(`modules/${MODULO}/module.json`)).json()).packFolders ?? []; } catch { return []; }
}

function classeFolder() {
  return foundry.documents?.Folder ?? globalThis.getDocumentClass?.("Folder") ?? globalThis.Folder;
}

// Pasta de compêndio com esse nome dentro de `pai` (null = raiz); cria se não existir.
async function pastaDe(no, pai) {
  const existente = game.folders.find((f) => f.type === "Compendium" && f.name === no.name && (f.folder?.id ?? null) === (pai?.id ?? null));
  if (existente) return existente;
  return classeFolder().create({ name: no.name, type: "Compendium", color: no.color ?? null, sorting: no.sorting ?? "m", folder: pai?.id ?? null });
}

async function colocar(pack, pasta) {
  if (typeof pack.setFolder === "function") return pack.setFolder(pasta);
  return pack.configure({ folder: pasta.id });
}

// Devolve quantos compêndios foram postos numa pasta agora.
export async function organizarCompendios() {
  const feitos = { ...(game.settings.get(MODULO, "compendiosOrganizados") ?? {}) };
  let movidos = 0;
  let mudou = false;

  const visitar = async (no, pai) => {
    let pasta = null; // só cria a pasta se algum compêndio abaixo dela precisar
    const garantir = async () => (pasta ??= await pastaDe(no, await pai()));
    for (const nome of lista(no.packs)) {
      const id = `${MODULO}.${nome}`;
      const pack = game.packs.get(id);
      if (!pack || feitos[id]) continue;
      if (!pack.folder) { await colocar(pack, await garantir()); movidos++; }
      feitos[id] = true; mudou = true;
    }
    for (const filho of lista(no.folders)) await visitar(filho, garantir);
  };
  for (const raiz of await arvoreDoManifesto()) await visitar(raiz, async () => null);

  if (mudou) await game.settings.set(MODULO, "compendiosOrganizados", feitos);
  if (movidos) console.log(`${MODULO} | ${movidos} compêndio(s) postos na pasta do módulo.`);
  return movidos;
}
