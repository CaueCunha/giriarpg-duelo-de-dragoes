// Importador: lê data/revista-NN.json e cria (ou recria) os documentos no mundo.
// Cada documento tem um _id fixo gerado no pacote, então reimportar substitui o anterior
// sem quebrar tokens já colocados nas cenas (eles apontam para o mesmo id).
import { MODULO, CAMINHO } from "./constantes.mjs";

const TIPOS = [
  // [chave no pacote, classe, coleção, tipo de pasta]
  ["actors", "Actor", () => game.actors, "Actor"],
  ["items", "Item", () => game.items, "Item"],
  ["tables", "RollTable", () => game.tables, "RollTable"],
  ["macros", "Macro", () => game.macros, "Macro"],
  ["journals", "JournalEntry", () => game.journal, "JournalEntry"],
  ["scenes", "Scene", () => game.scenes, "Scene"],
];

export async function listarRevistas() {
  const r = await fetch(`${CAMINHO}/data/indice.json`, { cache: "no-store" });
  if (!r.ok) throw new Error("Não achei data/indice.json no módulo.");
  return r.json();
}

async function carregarPacote(arquivo) {
  const r = await fetch(`${CAMINHO}/data/${arquivo}`, { cache: "no-store" });
  if (!r.ok) throw new Error(`Não achei data/${arquivo} no módulo.`);
  return r.json();
}

// Pastas no mundo iguais às dos compêndios: Duelo de Dragões › patamar › revista (Ferramentas gerais fica direto
// na raiz). Pastas de versões antigas (revista direto na raiz, antes da 0.18.0, ou "Revista 2" sem o zero) são
// reaproveitadas: só mudam de nome, cor e lugar, com os documentos e subpastas que o mestre pôs dentro.
const nomesAntigos = (titulo) => [...new Set([titulo, titulo.replace(/^Revista 0(\d) /, "Revista $1 ")])];

async function garantirPasta(nome, tipo, pai = null, { cor = "#7a1f1f", sorting = "a", sort = 0, antigoPai, antigos = [nome] } = {}) {
  const em = (p, nomes) => game.folders.find((f) => nomes.includes(f.name) && f.type === tipo && (f.folder?.id ?? null) === (p?.id ?? null));
  const existente = em(pai, [nome]);
  if (existente) return existente;
  const antiga = em(pai, antigos) ?? (antigoPai !== undefined && antigoPai !== pai ? em(antigoPai, antigos) : null);
  if (antiga) {
    await antiga.update({ name: nome, folder: pai?.id ?? null, color: cor, sort });
    return antiga;
  }
  return Folder.create({ name: nome, type: tipo, folder: pai?.id ?? null, color: cor, sorting, sort });
}

async function pastaDaRevista(info, tipo) {
  const raiz = await garantirPasta("Duelo de Dragões", tipo, null, { sorting: "a" });
  const pat = info.patamar;
  if (!pat) return garantirPasta(info.titulo, tipo, raiz, { cor: "#6b5a2f" });
  const patamar = await garantirPasta(pat.titulo, tipo, raiz, { cor: pat.cor, sorting: "m", sort: pat.ordem * 100000 });
  return garantirPasta(info.titulo, tipo, patamar, { cor: pat.cor, sort: Number(info.nivel) * 1000, antigoPai: raiz, antigos: nomesAntigos(info.titulo) });
}

// Última vez que o documento (ou algo embutido nele: itens, efeitos, páginas, resultados) foi alterado.
function ultimaEdicao(doc) {
  let t = doc._stats?.modifiedTime ?? 0;
  for (const col of ["items", "effects", "pages", "results"]) {
    for (const sub of doc[col] ?? []) t = Math.max(t, ultimaEdicao(sub));
  }
  return t;
}

// Documentos da revista que o mestre editou no Foundry depois da última importação.
// Cenas ficam de fora: elas nunca são apagadas pelo importador.
export function editadosDesde(chave) {
  const registro = game.settings.get(MODULO, "importadas")[chave];
  if (!registro?.emMs) return [];
  const mantidos = new Set(registro.mantidos ?? []);
  const editados = [];
  for (const [, Classe, colecao] of TIPOS) {
    if (Classe === "Scene") continue;
    for (const d of colecao().filter((d) => d.getFlag(MODULO, "revista") === chave)) {
      if (mantidos.has(d.id) || ultimaEdicao(d) > registro.emMs) editados.push({ id: d.id, nome: d.name, tipo: Classe });
    }
  }
  return editados;
}

export async function importarRevista(chave, { log = (m) => ui.notifications.info(m), sobrescrever = false } = {}) {
  if (!game.user.isGM) throw new Error("Só o mestre importa revistas.");
  const indice = await listarRevistas();
  const info = indice.revistas.find((r) => r.chave === chave);
  if (!info) throw new Error(`Revista ${chave} não está no índice.`);
  const pacote = await carregarPacote(info.arquivo);
  const resumo = [];
  // Por padrão, o que foi editado no Foundry depois da última importação é mantido.
  const manter = new Set(sobrescrever ? [] : editadosDesde(chave).map((e) => e.id));
  for (const [k, Classe, colecao, tipoPasta] of TIPOS) {
    const docs = [...(pacote[k] ?? [])].filter((d) => !manter.has(d._id));
    if (!docs.length) continue;
    const pasta = await pastaDaRevista(info, tipoPasta);
    // Cenas existentes não são apagadas (guardam tokens, paredes e notas do mestre): só atualizamos a imagem e o grid.
    if (Classe === "Scene") {
      const existentes = docs.filter((d) => colecao().get(d._id));
      for (const d of existentes) {
        const { _id, name, background, width, height, padding, grid, environment, weather } = d;
        await colecao().get(_id).update({ name, background, width, height, padding, grid, environment, weather, folder: pasta.id });
      }
      docs.splice(0, docs.length, ...docs.filter((d) => !colecao().get(d._id)));
      if (!docs.length) { resumo.push(`${existentes.length} Scene (atualizadas)`); continue; }
    }
    const ids = docs.map((d) => d._id);
    const velhos = ids.filter((id) => colecao().get(id));
    if (velhos.length) await getDocumentClass(Classe).deleteDocuments(velhos);
    const dados = docs.map((d) => {
      const c = foundry.utils.deepClone(d);
      c.folder = pasta.id;
      foundry.utils.setProperty(c, `flags.${MODULO}.revista`, chave);
      return c;
    });
    await getDocumentClass(Classe).createDocuments(dados, { keepId: true, keepEmbeddedIds: true });
    resumo.push(`${docs.length} ${Classe}`);
  }
  const registro = foundry.utils.deepClone(game.settings.get(MODULO, "importadas"));
  const agora = Date.now();
  // Documentos mantidos continuam contando como editados nas próximas reimportações.
  registro[chave] = { versao: pacote.versao, hash: info.hash, em: new Date(agora).toISOString(), emMs: agora, mantidos: [...manter] };
  await game.settings.set(MODULO, "importadas", registro);
  if (manter.size) resumo.push(`${manter.size} mantidos por terem sido editados por você`);
  log(`${info.titulo} importada: ${resumo.join(", ")}.`);
  return resumo;
}

export async function removerRevista(chave) {
  if (!game.user.isGM) throw new Error("Só o mestre remove revistas.");
  for (const [, Classe, colecao] of TIPOS) {
    const ids = colecao().filter((d) => d.getFlag(MODULO, "revista") === chave).map((d) => d.id);
    if (ids.length) await getDocumentClass(Classe).deleteDocuments(ids);
  }
  const registro = foundry.utils.deepClone(game.settings.get(MODULO, "importadas"));
  // Fica marcada como removida para a sincronização automática não trazê-la de volta.
  registro[chave] = { removida: true, em: new Date().toISOString() };
  await game.settings.set(MODULO, "importadas", registro);
  ui.notifications.info(`Revista ${chave} removida do mundo.`);
}

// Sincronização automática (ao abrir o mundo, mestre ativo): cria no mundo as revistas novas e reimporta
// as que mudaram no módulo (impressão digital "hash" do índice). O que o mestre editou é mantido,
// como no botão Reimportar. Revistas removidas pelo mestre ficam de fora.
export async function sincronizar() {
  const indice = await listarRevistas();
  const registro = game.settings.get(MODULO, "importadas");
  const feitas = [];
  for (const info of indice.revistas) {
    const atual = registro[info.chave];
    if (atual?.removida || (atual && atual.hash === info.hash)) continue;
    try {
      const resumo = await importarRevista(info.chave, { log: () => {} });
      feitas.push(`<li><b>${info.titulo}</b>${atual ? " (atualizada)" : " (nova)"}: ${resumo.join(", ")}</li>`);
    } catch (e) {
      console.error(e);
      feitas.push(`<li><b>${info.titulo}</b>: falhou (${e.message})</li>`);
    }
  }
  if (!feitas.length) return;
  ChatMessage.create({
    whisper: ChatMessage.getWhisperRecipients("GM"),
    content: `<h3>Duelo de Dragões</h3><p>O módulo atualizou o mundo:</p><ul>${feitas.join("")}</ul>`
      + "<p><small>Documentos editados por você foram mantidos. Para desligar, veja as configurações do módulo.</small></p>",
  });
}

// Mundos importados antes da 0.18.0 têm as revistas direto em "Duelo de Dragões", com "Revista 2" sem o zero.
// Move cada pasta de revista (com tudo o que está dentro) para a pasta do patamar e acerta o nome, sem reimportar
// nada. Não cria pastas onde não há revista.
export async function organizarPastas(indice) {
  const movidas = [];
  for (const [, , , tipo] of TIPOS) {
    const raiz = game.folders.find((f) => f.name === "Duelo de Dragões" && f.type === tipo && !f.folder);
    if (!raiz) continue;
    for (const info of indice.revistas) {
      if (!info.patamar) continue;
      const velhos = nomesAntigos(info.titulo).filter((n) => n !== info.titulo);
      const antiga = game.folders.find((f) => f.type === tipo && ((f.folder?.id === raiz.id && nomesAntigos(info.titulo).includes(f.name))
        || (velhos.includes(f.name) && f.folder?.name === info.patamar.titulo && f.folder?.folder?.id === raiz.id)));
      if (!antiga) continue;
      await pastaDaRevista(info, tipo);
      movidas.push(`${info.titulo} (${tipo})`);
    }
  }
  return movidas;
}

// Substituição única (pedida pelo Cauê na 0.19.1): troca no mundo tudo o que veio das revistas pela versão corrigida
// do módulo, inclusive o que o mestre editou. Antes, cada documento editado ganha uma cópia (id novo, sem a marca
// da revista, então nenhuma importação mexe nela) na pasta "Duelo de Dragões / Cópias das suas edições (0.19.1)".
// Roda uma vez por mundo: a configuração "substituicao" guarda a rodada já feita.
export const RODADA_SUBSTITUICAO = "0.19.1";

export async function substituirTudo({ rodada = RODADA_SUBSTITUICAO } = {}) {
  if (game.settings.get(MODULO, "substituicao") === rodada) return null;
  const registro = game.settings.get(MODULO, "importadas");
  const indice = await listarRevistas();
  const linhas = [];
  let copias = 0;
  for (const info of indice.revistas) {
    const atual = registro[info.chave];
    if (!atual || atual.removida) continue;
    const editados = editadosDesde(info.chave);
    for (const [, Classe, colecao, tipo] of TIPOS) {
      const meus = editados.filter((e) => e.tipo === Classe).map((e) => colecao().get(e.id)).filter(Boolean);
      if (!meus.length) continue;
      const raiz = await garantirPasta("Duelo de Dragões", tipo, null, { sorting: "a" });
      const pasta = await garantirPasta(`Cópias das suas edições (${rodada})`, tipo, raiz, { cor: "#555555" });
      await getDocumentClass(Classe).createDocuments(meus.map((d) => {
        const c = d.toObject();
        delete c._id;
        c.name = `${d.name} (sua edição)`;
        c.folder = pasta.id;
        if (c.flags?.[MODULO]) delete c.flags[MODULO].revista;
        return c;
      }));
      copias += meus.length;
    }
    try {
      const resumo = await importarRevista(info.chave, { log: () => {}, sobrescrever: true });
      linhas.push(`<li><b>${info.titulo}</b>: ${resumo.join(", ")}${editados.length ? ` (${editados.length} editados, com cópia)` : ""}</li>`);
    } catch (e) {
      console.error(e);
      linhas.push(`<li><b>${info.titulo}</b>: falhou (${e.message})</li>`);
    }
  }
  await game.settings.set(MODULO, "substituicao", rodada);
  if (linhas.length) ChatMessage.create({
    whisper: ChatMessage.getWhisperRecipients("GM"),
    content: `<h3>Duelo de Dragões ${rodada}</h3><p>As revistas do mundo foram trocadas pela versão corrigida do módulo:</p><ul>${linhas.join("")}</ul>`
      + (copias ? `<p>${copias} documento(s) que você tinha editado ficaram guardados em <b>Duelo de Dragões / Cópias das suas edições (${rodada})</b>, com "(sua edição)" no nome. Pode apagar quando não precisar mais.</p>` : ""),
  });
  return { linhas, copias };
}

// Atualização única das macros (0.21.0, pedido do Cauê): as macros passaram a pedir os testes no chat em vez de rolar pelos heróis.
// Troca o código (command) de toda macro do mundo que veio do módulo, mesmo as que o mestre editou, e também as cópias
// que ele arrastou dos compêndios do módulo (para a barra de atalhos, por exemplo). A macro continua a mesma (mesmo id,
// nome, pasta e lugar na barra); só o código muda. Antes, cada macro editada ganha uma cópia "(sua edição)" na pasta
// "Duelo de Dragões / Cópias das suas edições (0.21.0)". Roda uma vez por mundo (configuração "macrosAtualizadas").
export const RODADA_MACROS = "0.21.0";
const origemDe = (d) => d._stats?.compendiumSource ?? d.flags?.core?.sourceId ?? "";

export async function atualizarMacros({ rodada = RODADA_MACROS } = {}) {
  if (game.settings.get(MODULO, "macrosAtualizadas") === rodada) return null;
  const indice = await listarRevistas();
  const registro = foundry.utils.deepClone(game.settings.get(MODULO, "importadas"));
  const linhas = [];
  let copias = 0;
  for (const info of indice.revistas) {
    const macros = (await carregarPacote(info.arquivo)).macros ?? [];
    if (!macros.length) continue;
    const editados = new Set(editadosDesde(info.chave).map((e) => e.id));
    let n = 0;
    for (const m of macros) {
      const doMundo = game.macros.filter((w) => w.id === m._id || origemDe(w).endsWith(`.${m._id}`));
      for (const w of doMundo) {
        if (w.command === m.command) continue;
        if (editados.has(w.id)) {
          const raiz = await garantirPasta("Duelo de Dragões", "Macro", null, { sorting: "a" });
          const pasta = await garantirPasta(`Cópias das suas edições (${rodada})`, "Macro", raiz, { cor: "#555555" });
          const c = w.toObject();
          delete c._id;
          c.name = `${w.name} (sua edição)`;
          c.folder = pasta.id;
          if (c.flags?.[MODULO]) delete c.flags[MODULO].revista;
          await getDocumentClass("Macro").createDocuments([c]);
          copias++;
        }
        await w.update({ command: m.command });
        n++;
      }
    }
    // A troca muda a data de edição das macros: renova a marca da importação, mas mantém protegido o que o mestre editou (fora as macros trocadas).
    const reg = registro[info.chave];
    if (n && reg && !reg.removida) {
      reg.emMs = Date.now();
      reg.mantidos = [...new Set([...(reg.mantidos ?? []), ...editados])].filter((id) => !macros.some((m) => m._id === id));
    }
    if (n) linhas.push(`<li><b>${info.titulo}</b>: ${n} macro(s)</li>`);
  }
  await game.settings.set(MODULO, "importadas", registro);
  await game.settings.set(MODULO, "macrosAtualizadas", rodada);
  if (linhas.length) ChatMessage.create({
    whisper: ChatMessage.getWhisperRecipients("GM"),
    content: `<h3>Duelo de Dragões ${rodada}</h3><p>As macros do mundo (inclusive as que você puxou dos compêndios) agora pedem os testes no chat: `
      + `cada jogador clica no botão do seu herói e rola, e você aplica o resultado pelos botões do cartão.</p><ul>${linhas.join("")}</ul>`
      + (copias ? `<p>${copias} macro(s) que você tinha editado ficaram guardadas em <b>Duelo de Dragões / Cópias das suas edições (${rodada})</b>, com "(sua edição)" no nome.</p>` : ""),
  });
  return { linhas, copias };
}
