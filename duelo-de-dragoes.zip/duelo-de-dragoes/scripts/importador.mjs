// Importador: lê data/revista-NN.json e cria (ou recria) os documentos no mundo.
// Cada documento tem um _id fixo gerado no pacote, então reimportar substitui o anterior
// sem quebrar tokens já colocados nas cenas (eles apontam para o mesmo id).
import { MODULO, CAMINHO } from "./constantes.mjs";

const TIPOS = [
  // [chave no pacote, classe, coleção, tipo de pasta]
  ["actors", "Actor", () => game.actors, "Actor"],
  ["items", "Item", () => game.items, "Item"],
  ["tables", "RollTable", () => game.tables, "RollTable"],
  ["macros", "Macro", () => game.macros, "Macro"],
  ["journals", "JournalEntry", () => game.journal, "JournalEntry"],
  ["scenes", "Scene", () => game.scenes, "Scene"],
];

export async function listarRevistas() {
  const r = await fetch(`${CAMINHO}/data/indice.json`, { cache: "no-store" });
  if (!r.ok) throw new Error("Não achei data/indice.json no módulo.");
  return r.json();
}

async function carregarPacote(arquivo) {
  const r = await fetch(`${CAMINHO}/data/${arquivo}`, { cache: "no-store" });
  if (!r.ok) throw new Error(`Não achei data/${arquivo} no módulo.`);
  return r.json();
}

async function garantirPasta(nome, tipo, pai = null) {
  const existente = game.folders.find((f) => f.name === nome && f.type === tipo && (f.folder?.id ?? null) === (pai?.id ?? null));
  if (existente) return existente;
  return Folder.create({ name: nome, type: tipo, folder: pai?.id ?? null, color: "#5b2a86" });
}

// Última vez que o documento (ou algo embutido nele: itens, efeitos, páginas, resultados) foi alterado.
function ultimaEdicao(doc) {
  let t = doc._stats?.modifiedTime ?? 0;
  for (const col of ["items", "effects", "pages", "results"]) {
    for (const sub of doc[col] ?? []) t = Math.max(t, ultimaEdicao(sub));
  }
  return t;
}

// Documentos da revista que o mestre editou no Foundry depois da última importação.
// Cenas ficam de fora: elas nunca são apagadas pelo importador.
export function editadosDesde(chave) {
  const registro = game.settings.get(MODULO, "importadas")[chave];
  if (!registro?.emMs) return [];
  const mantidos = new Set(registro.mantidos ?? []);
  const editados = [];
  for (const [, Classe, colecao] of TIPOS) {
    if (Classe === "Scene") continue;
    for (const d of colecao().filter((d) => d.getFlag(MODULO, "revista") === chave)) {
      if (mantidos.has(d.id) || ultimaEdicao(d) > registro.emMs) editados.push({ id: d.id, nome: d.name, tipo: Classe });
    }
  }
  return editados;
}

export async function importarRevista(chave, { log = (m) => ui.notifications.info(m), sobrescrever = false } = {}) {
  if (!game.user.isGM) throw new Error("Só o mestre importa revistas.");
  const indice = await listarRevistas();
  const info = indice.revistas.find((r) => r.chave === chave);
  if (!info) throw new Error(`Revista ${chave} não está no índice.`);
  const pacote = await carregarPacote(info.arquivo);
  const resumo = [];
  // Por padrão, o que foi editado no Foundry depois da última importação é mantido.
  const manter = new Set(sobrescrever ? [] : editadosDesde(chave).map((e) => e.id));
  for (const [k, Classe, colecao, tipoPasta] of TIPOS) {
    const docs = [...(pacote[k] ?? [])].filter((d) => !manter.has(d._id));
    if (!docs.length) continue;
    const raiz = await garantirPasta("Duelo de Dragões", tipoPasta);
    const pasta = await garantirPasta(info.titulo, tipoPasta, raiz);
    // Cenas existentes não são apagadas (guardam tokens, paredes e notas do mestre): só atualizamos a imagem e o grid.
    if (Classe === "Scene") {
      const existentes = docs.filter((d) => colecao().get(d._id));
      for (const d of existentes) {
        const { _id, name, background, width, height, padding, grid, environment, weather } = d;
        await colecao().get(_id).update({ name, background, width, height, padding, grid, environment, weather, folder: pasta.id });
      }
      docs.splice(0, docs.length, ...docs.filter((d) => !colecao().get(d._id)));
      if (!docs.length) { resumo.push(`${existentes.length} Scene (atualizadas)`); continue; }
    }
    const ids = docs.map((d) => d._id);
    const velhos = ids.filter((id) => colecao().get(id));
    if (velhos.length) await getDocumentClass(Classe).deleteDocuments(velhos);
    const dados = docs.map((d) => {
      const c = foundry.utils.deepClone(d);
      c.folder = pasta.id;
      foundry.utils.setProperty(c, `flags.${MODULO}.revista`, chave);
      return c;
    });
    await getDocumentClass(Classe).createDocuments(dados, { keepId: true, keepEmbeddedIds: true });
    resumo.push(`${docs.length} ${Classe}`);
  }
  const registro = foundry.utils.deepClone(game.settings.get(MODULO, "importadas"));
  const agora = Date.now();
  // Documentos mantidos continuam contando como editados nas próximas reimportações.
  registro[chave] = { versao: pacote.versao, hash: info.hash, em: new Date(agora).toISOString(), emMs: agora, mantidos: [...manter] };
  await game.settings.set(MODULO, "importadas", registro);
  if (manter.size) resumo.push(`${manter.size} mantidos por terem sido editados por você`);
  log(`${info.titulo} importada: ${resumo.join(", ")}.`);
  return resumo;
}

export async function removerRevista(chave) {
  if (!game.user.isGM) throw new Error("Só o mestre remove revistas.");
  for (const [, Classe, colecao] of TIPOS) {
    const ids = colecao().filter((d) => d.getFlag(MODULO, "revista") === chave).map((d) => d.id);
    if (ids.length) await getDocumentClass(Classe).deleteDocuments(ids);
  }
  const registro = foundry.utils.deepClone(game.settings.get(MODULO, "importadas"));
  // Fica marcada como removida para a sincronização automática não trazê-la de volta.
  registro[chave] = { removida: true, em: new Date().toISOString() };
  await game.settings.set(MODULO, "importadas", registro);
  ui.notifications.info(`Revista ${chave} removida do mundo.`);
}

// Sincronização automática (ao abrir o mundo, mestre ativo): cria no mundo as revistas novas e reimporta
// as que mudaram no módulo (impressão digital "hash" do índice). O que o mestre editou é mantido,
// como no botão Reimportar. Revistas removidas pelo mestre ficam de fora.
export async function sincronizar() {
  const indice = await listarRevistas();
  const registro = game.settings.get(MODULO, "importadas");
  const feitas = [];
  for (const info of indice.revistas) {
    const atual = registro[info.chave];
    if (atual?.removida || (atual && atual.hash === info.hash)) continue;
    try {
      const resumo = await importarRevista(info.chave, { log: () => {} });
      feitas.push(`<li><b>${info.titulo}</b>${atual ? " (atualizada)" : " (nova)"}: ${resumo.join(", ")}</li>`);
    } catch (e) {
      console.error(e);
      feitas.push(`<li><b>${info.titulo}</b>: falhou (${e.message})</li>`);
    }
  }
  if (!feitas.length) return;
  ChatMessage.create({
    whisper: ChatMessage.getWhisperRecipients("GM"),
    content: `<h3>Duelo de Dragões</h3><p>O módulo atualizou o mundo:</p><ul>${feitas.join("")}</ul>`
      + "<p><small>Documentos editados por você foram mantidos. Para desligar, veja as configurações do módulo.</small></p>",
  });
}
