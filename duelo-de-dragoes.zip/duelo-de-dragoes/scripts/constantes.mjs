export const MODULO = "duelo-de-dragoes";
export const CAMINHO = `modules/${MODULO}`;
// Só um cliente executa automações: o mestre ativo.
export const souMestreAtivo = () => (game.users.activeGM ?? game.users.find((u) => u.isGM && u.active))?.isSelf ?? false;
