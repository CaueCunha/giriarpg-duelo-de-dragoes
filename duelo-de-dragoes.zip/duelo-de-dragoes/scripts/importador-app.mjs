// Janela "Importar revistas": lista as revistas do pacote, mostra o que já foi importado
// e tem botões para importar (ou reimportar) e remover.
import { MODULO } from "./constantes.mjs";
import { importarRevista, removerRevista, listarRevistas, editadosDesde } from "./importador.mjs";

const { ApplicationV2 } = foundry.applications.api;

export class ImportadorApp extends ApplicationV2 {
  static DEFAULT_OPTIONS = {
    id: "ddd-importador",
    window: { title: "Duelo de Dragões: revistas", icon: "fas fa-dragon" },
    position: { width: 520, height: "auto" },
    actions: {
      importar: ImportadorApp.aoImportar,
      remover: ImportadorApp.aoRemover,
    },
  };

  async _prepareContext() {
    const indice = await listarRevistas();
    const feitas = game.settings.get(MODULO, "importadas");
    return { revistas: indice.revistas.map((r) => ({ ...r, feita: feitas[r.chave] })) };
  }

  async _renderHTML(context) {
    const linhas = context.revistas.map((r) => `
      <tr>
        <td><b>${r.titulo}</b><br><small>${r.descricao ?? ""}</small></td>
        <td>${r.feita ? `importada<br><small>${new Date(r.feita.em).toLocaleString()}</small>` : "—"}</td>
        <td style="white-space:nowrap">
          <button type="button" data-action="importar" data-chave="${r.chave}">${r.feita ? "Reimportar" : "Importar"}</button>
          ${r.feita ? `<button type="button" data-action="remover" data-chave="${r.chave}">Remover</button>` : ""}
        </td>
      </tr>`).join("");
    return `<div style="padding:8px">
      <p>Reimportar substitui as fichas, tabelas, macros, diários e cenas da revista pelos do módulo. Tokens já colocados continuam ligados às fichas.</p>
      <table><thead><tr><th>Revista</th><th>Estado</th><th></th></tr></thead><tbody>${linhas}</tbody></table>
    </div>`;
  }

  _replaceHTML(result, content) {
    content.innerHTML = result;
  }

  static async aoImportar(event, alvo) {
    const chave = alvo.dataset.chave;
    const editados = editadosDesde(chave);
    let sobrescrever = false;
    if (editados.length) {
      const lista = editados.map((e) => `<li>${e.nome} <small>(${e.tipo})</small></li>`).join("");
      const escolha = await foundry.applications.api.DialogV2.wait({
        window: { title: "Documentos editados por você" }, rejectClose: false,
        content: `<p>Você editou estes documentos depois da última importação:</p><ul>${lista}</ul>
          <p>Manter preserva suas mudanças e atualiza só o resto da revista.</p>`,
        buttons: [
          { action: "manter", label: "Manter minhas edições", default: true },
          { action: "substituir", label: "Substituir pela versão do módulo" },
        ],
      });
      if (!escolha) return;
      sobrescrever = escolha === "substituir";
    }
    alvo.disabled = true;
    try {
      await importarRevista(chave, { sobrescrever });
    } catch (e) {
      console.error(e);
      ui.notifications.error(`Falha ao importar: ${e.message}`);
    }
    this.render();
  }

  static async aoRemover(event, alvo) {
    const ok = await foundry.applications.api.DialogV2.confirm({
      window: { title: "Remover revista" },
      content: "<p>Apagar do mundo tudo o que o módulo criou para esta revista?</p>",
    });
    if (!ok) return;
    await removerRevista(alvo.dataset.chave);
    this.render();
  }
}
