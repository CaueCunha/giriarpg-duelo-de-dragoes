# Módulo Foundry "Duelo de Dragões"

Leva cada revista da campanha para o Foundry com um clique: fichas com tokens, parceiros, tabelas, macros, diários (plano do mestre, cartas e handouts). **Cenas e mapas não vêm no módulo**: você sobe cada mapa à mão para preparar a cena do seu jeito. As automações da campanha ficam ligadas enquanto o módulo estiver ativo.

Feito para **Foundry v14 + sistema Tormenta20 1.6.x** (declara compatibilidade a partir da v13, mas só foi pensado para a v14). Nada foi rodado num Foundry real ainda; a lógica do importador foi testada fora do Foundry, com o Foundry simulado.

## Instalar

1. Descompacte `duelo-de-dragoes.zip` dentro de `Data/modules/` do Foundry (fica `Data/modules/duelo-de-dragoes/module.json`). No Windows o padrão é `%localappdata%\FoundryVTT\Data\modules`.
2. Reinicie o Foundry, abra o mundo e ative o módulo em **Gerenciar Módulos**.
3. Abra **Configurações > Configurar Opções > Duelo de Dragões > Importar revistas** (ou rode `ddd.abrir()` no console) e clique em **Importar** em **Ferramentas gerais** (uma vez por mundo) e depois na revista.

Tudo vai para pastas "Duelo de Dragões / Revista N" em Atores, Itens, Tabelas, Macros e Diários. As macros que servem para a campanha toda (DdD · Teste estendido, DdD · Frio e o atalho do importador) ficam em "Duelo de Dragões / Ferramentas gerais".

## Reimportar e remover

- **Instalar uma versão nova do módulo não muda nada no mundo.** Só o botão Importar/Reimportar de uma revista cria ou troca documentos, e só os daquela revista. Importar a revista 3 nunca toca na 2.
- **Reimportar** atualiza fichas, itens, tabelas, macros e diários da revista. Os ids são fixos, então tokens já colocados continuam ligados às fichas.
- **Suas edições são preservadas:** o que você editou no Foundry depois da última importação (incluindo itens e efeitos dentro de uma ficha, páginas de diário e resultados de tabela) é listado antes de reimportar, e por padrão é mantido. Só é trocado se você escolher "Substituir pela versão do módulo". O que foi mantido uma vez continua protegido nas próximas reimportações.
- **Cenas que versões antigas do módulo criaram continuam no mundo**, intactas. Reimportar não as atualiza mais; Remover ainda apaga as que têm a flag do módulo.
- **Remover** apaga do mundo tudo o que o módulo criou para aquela revista (procura pela flag `duelo-de-dragoes.revista`).
- Para uma correção valer para sempre (e em mundos novos), peça aqui: ela é feita na fonte da revista e entra em toda versão nova do módulo.

## Automações (sempre ligadas, executadas pelo mestre ativo)

Cada ficha liga a sua por flag (`flags.duelo-de-dragoes.automacoes`):

| Chave | O que faz | Usado em |
|---|---|---|
| `ferocidade: true` | Ao perder PV, ganha +2 em ataque e dano até o fim do próximo turno | Carcaju (#2, #3) |
| `soproCompartilhado: "<grupo>"` | Só um membro do grupo usa o sopro por vez; recarrega quando um membro cai a 0 PV; avisa o mestre por sussurro | Cultistas de Kallyadranoch (#2) |

Novas revistas acrescentam chaves em `scripts/automacoes.mjs`.

## Como cada revista entra no módulo

Fonte de cada revista: `duelo-de-dragoes/revista-NN/`
- `foundry/gerar-json.py` gera `foundry/atores`, `foundry/itens` e `foundry/tabelas` (molde: Dragão Adulto do compêndio do sistema).
- `foundry/macros/*.js` (macros de script), `foundry/automacoes.json` (flags por ficha), `foundry/diarios/*.md` (um diário por arquivo, ex.: a carta de "E." na revista 3).
- As funções comuns de ficha ficam em `fonte/t20lib.py`; as macros gerais em `fonte/macros-gerais/`.
- `plano-revista-NN.md` vira o diário "Plano do mestre", uma página por seção.
- `assets/{tokens,handouts}` são cópias dos arquivos da pasta do Google Drive.

`python3 foundry-modulo/construir.py` junta tudo em `duelo-de-dragoes/data/revista-NN.json`, copia os assets e gera o zip. Para acrescentar uma revista: crie a pasta dela no mesmo formato e adicione uma linha em `REVISTAS` no `construir.py`.

## Arquivos do módulo

- `module.json`
- `scripts/main.mjs`: registra o menu e a API (`ddd.importarRevista("02")`, `ddd.removerRevista("02")`, `ddd.abrir()`).
- `scripts/importador.mjs` e `scripts/importador-app.mjs`: importação e janela.
- `scripts/automacoes.mjs`: ganchos das automações.
- `data/indice.json` e `data/revista-NN.json`: os pacotes.
- `data/geral.json`: o pacote Ferramentas gerais.
- `assets/revista-NN/`: tokens e handouts.

## O que testar primeiro

1. Importar a revista 2 num mundo de teste e abrir cada ficha (atributos, perícias, Defesa, ataques).
2. Pôr um carcaju numa cena, causar dano e ver se a Ferocidade aparece e some no fim do próximo turno.
3. Pôr 2 cultistas, usar o Sopro de Dragão de um, tentar o do outro (deve avisar) e derrubar um (deve recarregar).
4. Revista 3: rodar **R3 · Servos do dragão** com Cerise selecionada (gasta 2 PM e põe os kobolds), **R3 · Bugulentos** num herói e **R3 · Nevasca** ligando e desligando; arrastar o item **Montaria: Trobo** para um herói e ver se o deslocamento vira 9 m.
